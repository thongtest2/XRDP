while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://sg-stratum.coinminerz.com:3357 -u DCzJABt2pCJWxWCSZnMAeL6mAJ7W8hvsDH.test -p c=DGB -t 4
sleep 5
done
