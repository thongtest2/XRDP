while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3335 -u LMa1zxuCC4iQZTdkneEoRHVUZd9qGYDCQy -p x
sleep 5
done