while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3394 -u NTSosWpnvKUfPiXHsMkzqV6QrEmLuJovHV -p x
sleep 5
done