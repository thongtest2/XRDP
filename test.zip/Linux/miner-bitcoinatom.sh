while [ 1 ]; do
./cpuminer-avx2 -a sha256d -o stratum+tcp://stratum.coinminerz.com:3354 -u AMqAWx8QeNsUKZa8QAzE9J4BFyMJLAwoxh -p x
sleep 5
done