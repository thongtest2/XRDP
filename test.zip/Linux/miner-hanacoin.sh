while [ 1 ]; do
./cpuminer-avx2 -a lyra2v3 -o stratum+tcp://stratum.coinminerz.com:3355 -u HQcVJ86CK6PNCYAqq2WjxEbyLNS58XspZM -p x
sleep 5
done