while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3353 -u MGSToM8jsEcyirerpbpASdqwP7kmKY7R7D -p x
sleep 5
done