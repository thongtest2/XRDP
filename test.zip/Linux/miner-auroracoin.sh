while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3346 -u AVypadvpD9xPehg4Q96yZZaB1FaJb1fYEz.lappy -p x
sleep 5
done