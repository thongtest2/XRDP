while [ 1 ]; do
./cpuminer-avx2 -a qubit -o stratum+tcp://stratum.coinminerz.com:3344 -u D9k8sQMpoDHcHXZc4Lev6nx1fVy1qx4aAG -p x
sleep 5
done