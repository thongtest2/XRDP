while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3338 -u XTJuRQ7gSJcvAd54atGjXiWb1nwPQdnB5D -p x
sleep 5
done