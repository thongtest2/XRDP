while [ 1 ]; do
./cpuminer-avx2 -a sha256d -o stratum+tcp://stratum.coinminerz.com:3349 -u CWyU4pr3KXZghpsMtbWvXQ8EJnGA6Y5xu5 -p x
sleep 5
done