while [ 1 ]; do
./cpuminer-avx2 -a blake2s -o stratum+tcp://stratum.coinminerz.com:3345 -u DCf7x8Zsiq2i6XDxwnshRzi9GNjcVXi8cq -p x
sleep 5
done