while [ 1 ]; do
./cpuminer-avx2 -a sha256d -o stratum+tcp://stratum.coinminerz.com:3333 -u 1P4XWNwhLcoGNGVAVf6uC7uGdNnd51XdUu.lappy -p x
sleep 5
done