while [ 1 ]; do
./cpuminer-avx2 -a sha256d -o stratum+tcp://stratum.coinminerz.com:3336 -u PRQG79k1aGD4dqpdUFZ4nwQzEJTn6CsrmW -p x
sleep 5
done
