while [ 1 ]; do
./cpuminer-avx2 -a sha256d -o stratum+tcp://stratum.coinminerz.com:3339 -u NdPeNEN4FSGsYGsT7z5KsDyqnK6QYoyuRj -p x
sleep 5
done