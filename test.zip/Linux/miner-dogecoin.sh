while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3363 -u D7pFqjK91uizdfoBzCS57vzRW5APienCu1 -p x
sleep 5
done