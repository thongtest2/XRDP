while [ 1 ]; do
./cpuminer-avx2.exe -a scrypt -o stratum+tcp://stratum.coinminerz.com:3370 -u CPqAewMP1YKCCix3SbtYmugPEpop3FRBZ6 -p x
sleep 5
done