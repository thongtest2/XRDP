while [ 1 ]; do
./cpuminer-avx2 -a x11 -o stratum+tcp://stratum.coinminerz.com:3359 -u PW4nL6UeTgeWKRgaPGERGn7oqT2GRmFeVY.lappy -p x
sleep 5
done