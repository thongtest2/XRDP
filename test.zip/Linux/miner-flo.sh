while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3352 -u F9uPcApyGe2rtCHYBoseUDgTE7HPKbUcGe -p x
sleep 5
done