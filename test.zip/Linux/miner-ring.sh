while [ 1 ]; do
./cpuminer-sse2 -a minotaur -o stratum+tcp://stratum.coinminerz.com:3347 -u ZwhiqsZYSPNTxxpzFcPkf1kHQGcTtefhKC -p x
sleep 5
done
