while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3343 -u EcjhXFdesqo62tstiexAVu3c3jsmJeg3vj -p x
sleep 5
done