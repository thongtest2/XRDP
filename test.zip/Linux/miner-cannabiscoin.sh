while [ 1 ]; do
./cpuminer-avx2 -a x11 -o stratum+tcp://stratum.coinminerz.com:3351 -u CfhzDeWZr5Tcfk72Mg76vVzdhChX6rztuh -p x
sleep 5
done