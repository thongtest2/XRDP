while [ 1 ]; do
./cpuminer-avx2.exe -a x11 -o stratum+tcp://stratum.coinminerz.com:3379 -u PQHgHwX8N3hvUHMyCPUrDdpGK8jCg8S5rn -p x
sleep 5
done