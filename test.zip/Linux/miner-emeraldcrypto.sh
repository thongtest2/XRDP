while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3371 -u EhphkdbyJpQWCYDcxrZcfNapRABaY2uZWT -p x
sleep 5
done