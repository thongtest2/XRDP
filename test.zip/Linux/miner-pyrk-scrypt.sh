while [ 1 ]; do
./cpuminer-avx2 -a scrypt -o stratum+tcp://stratum.coinminerz.com:3380 -u PQHgHwX8N3hvUHMyCPUrDdpGK8jCg8S5rn -p x
sleep 5
done