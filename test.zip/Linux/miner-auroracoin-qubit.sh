while [ 1 ]; do
./cpuminer-avx2 -a qubit -o stratum+tcp://stratum.coinminerz.com:3342 -u AVypadvpD9xPehg4Q96yZZaB1FaJb1fYEz -p x
sleep 5
done