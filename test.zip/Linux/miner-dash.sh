while [ 1 ]; do
./cpuminer-avx2 -a x11 -o stratum+tcp://stratum.coinminerz.com:3360 -u Xdq3RP7b4NynV5e9naxEpiu15P9KRm7auP -p x
sleep 5
done