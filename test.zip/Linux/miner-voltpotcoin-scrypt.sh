while [ 1 ]; do
./cpuminer-avx2.exe -a scrypt -o stratum+tcp://stratum.coinminerz.com:3398 -u VNzZ3JJpVWMpBEhcqf4igj4Q3wC2qeczhS -p x
sleep 5
done